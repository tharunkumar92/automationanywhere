package ecommerseproject;

import java.util.Iterator;
import java.util.Set;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class AddItemToCart extends Flipkart {
	WebDriver driver;

	public AddItemToCart(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = "button[class='_2KpZ6l _2U9uOA _3v1-ww']")
	WebElement button;

	@FindBy(css = "a[class=\"_3SkBxJ\"]")
	WebElement cart;

	public void windowHandle() {
		Set<String> window = driver.getWindowHandles();
		Iterator<String> it = window.iterator();
		String parentId = it.next();
		String childId = it.next();
		driver.switchTo().window(childId);

	}

	public void addItemToCart() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,500)");
		button.click();
	}

	public void verifyItem() {
		cart.click();
	}

	public boolean isItemAddedToCart() {
		return driver.findElement(By.cssSelector("div[class='CXW8mj'] img[class='_396cs4']")).isDisplayed();

	}

}
