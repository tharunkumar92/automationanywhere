package ecommerseproject;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SearchBox extends Flipkart {

	WebDriver driver;

	public SearchBox(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);

	}

	@FindBy(css = "input[placeholder='Search for Products, Brands and More']")
	WebElement textBox;
	@FindBy(xpath = "//img[contains(@alt, 'MacBook AIR M2')]")
	WebElement firstItem;

	public void sendItem(String text) {
		textBox.sendKeys(text);
		Actions a = new Actions(driver);
		a.keyDown(Keys.ENTER).build().perform();
		;
	}

	public void clickFirstItem() {
		firstItem.click();
	}
}