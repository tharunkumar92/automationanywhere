package ecommerseproject;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

import org.openqa.selenium.chrome.ChromeDriver;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Flipkart {
	WebDriver driver;

	@BeforeClass
	public void setUp() throws InterruptedException {

		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
		driver.get("https://www.flipkart.com/");
	}

	@Test
	public void test() {

		driver.findElement(By.cssSelector("span[role='button']")).click();
		boolean logoPresent = driver.findElement(By.xpath("//img[@title='Flipkart']")).isDisplayed();
		Assert.assertTrue(logoPresent);
		SearchBox search = new SearchBox(driver);
		search.sendItem("Macbook air m2");
		search.clickFirstItem();
		AddItemToCart cart = new AddItemToCart(driver);
		cart.windowHandle();
		cart.addItemToCart();
		cart.verifyItem();
		boolean isItemAdded = cart.isItemAddedToCart();
		Assert.assertTrue(isItemAdded);

	}

	@AfterClass
	public void tearDown() {
		driver.quit();
	}

}
